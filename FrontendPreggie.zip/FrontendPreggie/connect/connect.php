<?php
	$conn = mysqli_connect("localhost","root","","preggie") or die ("gagal server");
?>